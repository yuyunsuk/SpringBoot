package com.dw.lms.repository;

import com.dw.lms.model.Code_class;
import org.springframework.data.jpa.repository.JpaRepository;

public interface Code_classRepository extends JpaRepository<Code_class, String> {

}
