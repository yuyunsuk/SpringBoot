package com.dw.lms.repository;

import com.dw.lms.model.Learning_contents;
import org.springframework.data.jpa.repository.JpaRepository;

public interface LearningContentsRepository extends JpaRepository<Learning_contents, Long> {
}
