package com.dw.lms.service;

import com.dw.lms.model.User;
import com.dw.lms.repository.UserRepository;
import jakarta.transaction.Transactional;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
@Transactional
public class UserDetailService implements UserDetailsService { // UserDetailsService 인터페이스 상속받아서 loadUserByUsername method 를 만들어야 함(Override).
    private final UserRepository userRepository;

    public UserDetailService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        Optional<User> user = userRepository.findByUserId(username);
        if (user.isEmpty()) {
            throw new IllegalArgumentException(username);
        }
        return user.get();
    }
}
