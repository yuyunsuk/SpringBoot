package com.dw.lms.repository;

import com.dw.lms.model.Lms_notices;
import org.springframework.data.jpa.repository.JpaRepository;

public interface Lms_noticesRepository extends JpaRepository<Lms_notices, Long> {
}