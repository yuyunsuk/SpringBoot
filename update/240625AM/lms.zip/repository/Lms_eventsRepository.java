package com.dw.lms.repository;

import com.dw.lms.model.Lms_events;
import org.springframework.data.jpa.repository.JpaRepository;

public interface Lms_eventsRepository extends JpaRepository<Lms_events, Long> {
}