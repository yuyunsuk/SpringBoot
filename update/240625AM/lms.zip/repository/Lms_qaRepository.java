package com.dw.lms.repository;

import com.dw.lms.model.Lms_qa;
import org.springframework.data.jpa.repository.JpaRepository;

public interface Lms_qaRepository extends JpaRepository<Lms_qa, Long> {
}
