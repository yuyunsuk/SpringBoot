package com.dw.lms.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AnswerDto {
    private String lmsQaAnswerContent;
    private String lmsQaAnswerWriter;
    private String lmsQaAnswerDate;
    private String lmsQaAnswerCheck;
}
